<?php
header("Location:odlozene/logout.php");