<?php

$id= $_GET['id'];
$pid= $_GET['pid'];
echo "meno herca je  ".$id;echo"<br>";
echo "cislo projektu je  ".$pid;echo"<br>";