

<?php
include ("pomocne/connection.php");
session_start();
$myactors=$_SESSION['project_id']."actors";
$mybusy=$_SESSION['project_id']."busy";


$myscenes=$_SESSION['project_id']."scenes";;
//$myactors="4904607actors";
//$mybusy="4904607busy";
//$hercisc=array();
//$hercikal=array();

echo"tu sa ukazu vsetky obrazy ktore je mozne natocit dany den podla zaneprazdnenosti hercov v obrazoch";
//vyberie dni s kalendaru

$sql5="SELECT distinct date FROM $mybusy order by date";
$run5=mysqli_query($con,$sql5);
while($row5=mysqli_fetch_assoc($run5)){
    $datumy []= $row5['date'];}

    foreach ($datumy as $datum){
        echo "<br>";
                echo   date('Y-m-d', $datum);echo "<br>";

                    // vyberie hercov ktory v jednotlive dni maju status 1
                    $sql="SELECT * FROM $mybusy WHERE date=$datum AND STATUS in(1,2) ";

                    $run=mysqli_query($con,$sql);
                        array_splice($hercikal,0);
                        while($row=mysqli_fetch_assoc($run)){
                                                              $hercikal[]= $row['role'];


                                                  };

                                // vyberie z druhej tabulky udaje ktore su zapisane ako string

                                $sql7="select * from $myscenes ";
                                $run7=mysqli_query($con,$sql7);
                                while($row7=mysqli_fetch_assoc($run7)) {

                                         $obraz = $row7['scene'];
                                        $herciscenar = $row7['cast'];
                                        $herci_id=$row7['cast_id'];
                                    $syn=$row7['synopsis'];
                                    $ie=$row7['intext'];
                                    $dn=$row7['daynight'];
                                    $set=$row7['filmset'];
                                    $pc=$row7['pagescount'];
                                         $hercisc = explode(",",$herciscenar);
                                              $pocethercovscenar=count($hercisc);

                                              //obmedzenie

                                    // tu je to porovnanie

                                                          $res=array_intersect($hercikal,$hercisc);
                                                           $pocetmatch=count($res);


                                                          if ($pocetmatch>=$pocethercovscenar){
                                                                                        echo $obraz." ".$ie."/".$dn."/".$herciscenar."/".$set."/".$syn.$datum;echo "<br>";

                                                                                              }else{

                                                                                        }



                                                                  };

        $red=0;




};
echo "<br>";echo "<br>";echo "<br>";
?>
<html>
<div>
    <a href="home.php" class="btn btn-outline-primary  btn-inline">Menu</a>
</div>
</html>
