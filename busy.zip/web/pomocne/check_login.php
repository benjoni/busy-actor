<?php


if(!isset($_SESSION['user_name']))
{
    //redirect to login
    header("Location:odlozene/logout.php");



    }



die;

