<!-- BEGIN: Vendor JS-->
<script src="../app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<script src="../app-assets/js/core/app-menu.js"></script>
<script src="../app-assets/js/core/app.js"></script>
<script src="../app-assets/js/scripts/components.js"></script>
<script src="../app-assets/vendors/js/charts/apexcharts.min.js"></script>


<script src="../app-assets/js/scripts/pages/dashboard-analytics.js"></script>
<script src="../app-assets/js/scripts/datatables/datatable.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/dataTables.select.min.js"></script>
<script src="../app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js"></script>
<script src="../app-assets/vendors/js/extensions/dropzone.min.js"></script>
<script src="../app-assets/js/scripts/ui/data-list-view.js"></script>
<script src="../app-assets/vendors/js/extensions/moment.min.js"></script>
<script src="../app-assets/vendors/js/calendar/fullcalendar.min.js"></script>
<script src="../app-assets/vendors/js/calendar/extensions/daygrid.min.js"></script>
<script src="../app-assets/vendors/js/calendar/extensions/timegrid.min.js"></script>
<script src="../app-assets/vendors/js/calendar/extensions/interactions.min.js"></script>
<script src="../app-assets/vendors/js/pickers/pickadate/picker.js"></script>
<script src="../app-assets/vendors/js/pickers/pickadate/picker.date.js"></script>
<script src="../app-assets/js/scripts/extensions/fullcalendar.js"></script>
<script src="../app-assets/js/scripts/ui/data-list-view.js"></script>
<!-- END: Theme JS-->

</body>
<!-- END: Body-->

</html>