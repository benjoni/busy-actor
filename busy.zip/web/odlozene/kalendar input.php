<!-- calendar Modal starts-->
<div class="modal fade text-left modal-calendar" tabindex="-1" role="dialog" aria-labelledby="cal-modal" aria-modal="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-text-bold-600" id="cal-modal">Add</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="#">
                <div class="modal-body">



                    <div class="row">

                        <div class="col-sm-6 col-12">

                            <div class="form-group">
                                <?php   $query = "select name from actors" ;
                                $run = mysqli_query($con, $query);
                                ?>
                                <select class="select2 form-control">
                                    <?php
                                    while($user_data = mysqli_fetch_assoc($run)){
                                        ?>
                                        <option value=$user_data['name']><?php echo $user_data['name']?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>



                    </div>






                    <fieldset class="form-label-group">
                        <input type="text" class="form-control pickadate" id="cal-start-date" placeholder="Date">
                        <label for="date">Date</label>
                    </fieldset>


                    <div class="row">
                        <div class="col-12">



                            <div class="card-body">

                                <ul class="list-unstyled mb-0">

                                    <li class="d-inline-block mr-2">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-danger">
                                                <input type="radio" name="radiocolor" checked value="false">
                                                <span class="vs-radio">
                                                                                    <span class="vs-radio--border"></span>
                                                                                    <span class="vs-radio--circle"></span>
                                                                                </span>
                                                <span class="">NO</span>
                                            </div>
                                        </fieldset>
                                    </li>
                                    <li class="d-inline-block mr-2">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-success">
                                                <input type="radio" name="radiocolor" value="false">
                                                <span class="vs-radio">
                                                                                    <span class="vs-radio--border"></span>
                                                                                    <span class="vs-radio--circle"></span>
                                                                                </span>
                                                <span class="">YES</span>
                                            </div>
                                        </fieldset>
                                    </li>

                                    <li class="d-inline-block mr-2">
                                        <fieldset>
                                            <div class="vs-radio-con vs-radio-info">
                                                <input type="radio" name="radiocolor" value="false">
                                                <span class="vs-radio">
                                                                                        <span class="vs-radio--border"></span>
                                                                                        <span class="vs-radio--circle"></span>
                                                                                    </span>
                                                <span class="">SOMETIMES</span>
                                            </div>
                                        </fieldset>
                                    </li>

                                </ul>

                            </div>

                        </div>
                    </div>



                    <div class="row match-height">
                        <div class="col-md-6 col-6 ">
                            <label for="cal-end-date">From # 1</label>
                            <form>
                                <input type='text' class="form-control pickatime" />
                            </form>
                        </div>
                        <div class="col-md-6 col-6 ">
                            <label for="cal-end-date">Until # 1</label>
                            <form>
                                <input type='text' class="form-control pickatime disabled" />
                            </form>
                        </div>
                    </div>


                    <div class="row match-height">
                        <div class="col-md-6 col-6 ">
                            <label for="cal-end-date">From # 2</label>
                            <form>
                                <input type='text' class="form-control pickatime" />
                            </form>
                        </div>
                        <div class="col-md-6 col-6 ">
                            <label for="cal-end-date">Until # 2</label>
                            <form>
                                <input type='text' class="form-control pickatime" />
                            </form>
                        </div>
                    </div>


                    <div class="card-body">
                        <fieldset class="form-label-group">
                            <textarea class="form-control" id="cal-description" rows="5" placeholder="Description"></textarea>
                            <label for="cal-description">Description</label>
                        </fieldset>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary cal-add-event waves-effect waves-light" disabled>
                            Add Event</button>
                        <button type="button" class="btn btn-primary d-none cal-submit-event waves-effect waves-light" submit</button>
                        <button type="button" class="btn btn-flat-danger cancel-event waves-effect waves-light" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-flat-danger remove-event d-none waves-effect waves-light" data-dismiss="modal">Remove</button>
                    </div>
            </form>
        </div>
    </div>
</div>
<!-- calendar Modal ends-->