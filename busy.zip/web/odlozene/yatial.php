<!-- DataTable starts -->
<div class="table-responsive">
    <table class="table data-list-view">
        <thead>
        <tr>
            <th></th>
            <th>NAME</th>
            <th>ROLE</th>
            <th>EMAIL</th>
            <th>PHONE</th>
            <th>ACTION</th>
        </tr>
        </thead>
        <?php   $query = "select * from actors" ;
        $run = mysqli_query($con, $query);
        ?>
        <tbody>
        <?php
        while($user_data = mysqli_fetch_assoc($run)){
            ?>
            <tr>
                <td></td>
                <td class="product-name"><?php echo $user_data['name']?></td>
                <td class="product-category"><?php echo $user_data['role']?></td>
                <td class="product-category"><?php echo $user_data['email']?></td>
                <td class="product-category"><?php echo $user_data['phone']?></td>
                <td>
                    <div class="chip chip-warning">
                        <div class="chip-body">
                            <div class="chip-text">actor</div>
                        </div>
                    </div>
                </td>

                <td class="product-action">
                    <span class="action-edit"><i class="feather icon-edit"></i></span>
                    <span class="action-delete"><i class="feather icon-trash"></i></span>
                </td>
            </tr>
        <?php }

        ?>


        </tbody>
    </table>
</div>
<!-- DataTable ends -->

<!-- export excel start -->
<div>
    <form class="form-horizontal" action="pomocne/functions.php" method="post" name="upload_excel"
          enctype="multipart/form-data">
        <div class="form-group">
            <div class="col-md-4 col-md-offset-4">
                <input type="submit" name="Export" class="btn btn-success" value="export to excel"/>
            </div>
        </div>
    </form>
</div>
<!-- export excel end -->
